Art and textures by Anna Tomatzidou

https://twitter.com/ShinyouArt

Gunshot Sound from BBC Sound Effects

https://sound-effects.bbcrewind.co.uk/

Music: Love Hurts by Ryuno 2008 (Royalty Free)
